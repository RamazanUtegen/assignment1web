/* Assignment 5: DOM updates, events, callbacks, data structures and sound.
   Everything runs in the browser. No account or server is required. */
(() => {
    'use strict';

    const storage = {
        read(key, fallback) {
            try { return JSON.parse(localStorage.getItem('kz-' + key)) ?? fallback; }
            catch { return fallback; }
        },
        write(key, value) {
            try { localStorage.setItem('kz-' + key, JSON.stringify(value)); }
            catch { /* Keep controls usable when browser storage is unavailable. */ }
        }
    };

    // Objects group each destination's properties and its route-building method.
    const destinations = [
        { id: 'aktau', name: 'Aktau', category: 'nature', tags: 'sea coast desert canyons mangystau',
            description: 'A Caspian escape, with wide horizons and dramatic landscapes.',
            stops: ['Walk the Caspian waterfront and discover Aktau.', 'Explore Mangystau chalk formations with a local guide.', 'Make time for the Bozjyra landscapes and the open steppe.'] },
        { id: 'astana', name: 'Astana', category: 'city', tags: 'capital architecture city river',
            description: 'A fresh perspective on architecture, art and life on the steppe.',
            stops: ['Explore the Baiterek area and Nurzhol Boulevard.', 'Discover Khan Shatyr and the city architecture.', 'Take a slower walk beside the Ishim River.'] },
        { id: 'almaty', name: 'Almaty', category: 'nature', tags: 'mountains lakes hiking city',
            description: 'City culture and mountain air, with room to slow down.',
            stops: ['Discover central Almaty and its leafy streets.', 'Head towards Medeu and Shymbulak; check mountain conditions.', 'Explore an alpine landscape with suitable local transport.'] },
        { id: 'shymkent', name: 'Shymkent', category: 'culture', tags: 'food silk road parks bazaar history',
            description: 'Southern hospitality, green spaces and Silk Road stories.',
            stops: ['Wander through Shymkent parks and the city centre.', 'Explore local bazaars and southern Kazakh flavours.', 'Plan a day around the region’s Silk Road heritage.'] }
    ].map(destination => ({
        ...destination,
        getRoute(days) { return this.stops.slice(0, days); }
    }));

    function animate(element) {
        if (!element) return;
        element.classList.remove('ui-enter');
        // Restart the event-triggered CSS animation after the DOM update.
        void element.offsetWidth;
        element.classList.add('ui-enter');
    }

    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    document.body.append(toast);
    function notify(message) {
        document.dispatchEvent(new CustomEvent('kz:notify', { detail: { message } }));
    }

    // Web Audio synthesises a short chime: no downloads, autoplay or overlapping notes.
    let audioContext;
    let activeSound;
    let soundEnabled = false;
    let soundRequest = 0;
    const soundToggle = document.querySelector('[data-sound-toggle]');
    function stopChime() {
        if (!activeSound) return;
        activeSound.stop();
        activeSound.disconnect();
        activeSound = null;
    }
    async function playChime() {
        if (!soundEnabled) return;
        const request = ++soundRequest;
        const AudioContextType = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextType) {
            notify('Sound is unavailable in this browser.');
            return;
        }
        try {
            audioContext ??= new AudioContextType();
            await audioContext.resume();
            // Resume can finish after muting or a newer discovery; discard stale requests.
            if (!soundEnabled || request !== soundRequest) return;
            stopChime();
            const oscillator = audioContext.createOscillator();
            const gain = audioContext.createGain();
            const now = audioContext.currentTime;
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(660, now);
            oscillator.frequency.setValueAtTime(880, now + 0.09);
            gain.gain.setValueAtTime(0.0001, now);
            gain.gain.exponentialRampToValueAtTime(0.12, now + 0.015);
            gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.23);
            oscillator.connect(gain);
            gain.connect(audioContext.destination);
            activeSound = oscillator;
            oscillator.onended = () => {
                oscillator.disconnect();
                gain.disconnect();
                if (activeSound === oscillator) activeSound = null;
            };
            oscillator.start(now);
            oscillator.stop(now + 0.24);
        } catch {
            if (soundEnabled && request === soundRequest) notify('Your browser could not play the sound.');
        }
    }
    soundToggle?.addEventListener('click', () => {
        soundEnabled = !soundEnabled;
        soundToggle.setAttribute('aria-pressed', String(soundEnabled));
        soundToggle.setAttribute('aria-label', soundEnabled ? 'Disable sound effects' : 'Enable sound effects');
        notify(soundEnabled ? 'Sound on. A little chime for your discoveries.' : 'Sound off.');
        if (soundEnabled) playChime();
        else {
            soundRequest += 1;
            stopChime();
        }
    });

    const themeToggle = document.querySelector('[data-theme-toggle]');
    function applyTheme(theme) {
        document.body.dataset.theme = theme;
        document.body.dataset.bsTheme = theme === 'night' ? 'dark' : 'light';
        themeToggle?.setAttribute('aria-pressed', String(theme === 'night'));
        themeToggle?.setAttribute('aria-label', theme === 'night' ? 'Switch to day theme' : 'Switch to night theme');
        document.dispatchEvent(new Event('kz-theme-change'));
    }
    applyTheme(storage.read('theme', 'day') === 'night' ? 'night' : 'day');
    themeToggle?.addEventListener('click', () => {
        const theme = document.body.dataset.theme === 'night' ? 'day' : 'night';
        applyTheme(theme);
        storage.write('theme', theme);
    });

    // Arrow keys move focus through the real navigation links without trapping Tab.
    const menuLinks = Array.from(document.querySelectorAll('#main-navigation .nav-link'));
    for (let index = 0; index < menuLinks.length; index += 1) {
        menuLinks[index].addEventListener('keydown', event => {
            let nextIndex;
            switch (event.key) {
                case 'ArrowRight': case 'ArrowDown': nextIndex = (index + 1) % menuLinks.length; break;
                case 'ArrowLeft': case 'ArrowUp': nextIndex = (index - 1 + menuLinks.length) % menuLinks.length; break;
                case 'Home': nextIndex = 0; break;
                case 'End': nextIndex = menuLinks.length - 1; break;
                default: return;
            }
            event.preventDefault();
            menuLinks[nextIndex].focus();
        });
    }

    const savedData = storage.read('saved', []);
    const saved = new Set(Array.isArray(savedData) ? savedData.filter(id => destinations.some(place => place.id === id)) : []);
    // Assignment 6 owns the search/filter UI through jQuery.
    function renderDestinations() {
        document.querySelectorAll('[data-saved-count]').forEach(label => { label.textContent = saved.size; });
        document.dispatchEvent(new Event('kz:destinations-change'));
    }
    document.querySelectorAll('[data-save]').forEach(button => {
        const id = button.dataset.save;
        const city = destinations.find(place => place.id === id).name;
        function updateButton() {
            const selected = saved.has(id);
            button.setAttribute('aria-pressed', String(selected));
            button.setAttribute('aria-label', `${selected ? 'Saved' : 'Save'} ${city}`);
            button.querySelector('span').textContent = selected ? 'Saved' : 'Save';
        }
        updateButton();
        button.addEventListener('click', () => {
            if (saved.has(id)) saved.delete(id); else saved.add(id);
            storage.write('saved', [...saved]);
            updateButton();
            renderDestinations(false);
            notify(saved.has(id) ? `Saved ${city}.` : `Removed ${city} from saved places.`);
            playChime();
        });
    });
    renderDestinations(false);

    // Thumbnails use Bootstrap's existing gallery, preserving previous/next/keyboard controls.
    document.querySelectorAll('[data-gallery-for]').forEach(thumbnails => {
        const carousel = document.getElementById(thumbnails.dataset.galleryFor);
        carousel?.addEventListener('slid.bs.carousel', event => {
            thumbnails.querySelectorAll('button').forEach((button, index) => {
                button.classList.toggle('is-active', index === event.to);
                button.setAttribute('aria-pressed', String(index === event.to));
            });
        });
    });

    document.querySelectorAll('[data-rating]').forEach(rating => {
        const stars = rating.querySelectorAll('[data-star]');
        const message = rating.querySelector('[data-rating-message]');
        const key = 'rating-' + rating.dataset.rating;
        let selected = Number(storage.read(key, 0));
        if (!Number.isInteger(selected) || selected < 0 || selected > 5) selected = 0;
        function renderRating() {
            stars.forEach(star => {
                star.classList.toggle('is-selected', Number(star.dataset.star) <= selected);
                star.setAttribute('aria-pressed', String(Number(star.dataset.star) === selected));
            });
            message.textContent = selected ? `Your rating: ${selected}/5. Thanks for exploring with us!` : 'Choose your rating';
        }
        stars.forEach(star => star.addEventListener('click', () => {
            selected = Number(star.dataset.star);
            storage.write(key, selected);
            renderRating();
            animate(message);
            playChime();
        }));
        renderRating();
    });

    const planner = document.querySelector('[data-trip-planner]');
    if (planner) {
        const steps = Array.from(planner.querySelectorAll('[data-planner-step]'));
        const result = planner.querySelector('[data-trip-result]');
        const back = planner.querySelector('[data-planner-back]');
        const next = planner.querySelector('[data-planner-next]');
        const fieldGroups = [
            [Array.from(planner.querySelectorAll('[name=destination]'))],
            [[planner.elements.traveler], [planner.elements.days]]
        ];
        const labels = ['Step 1 of 3 · Destination', 'Step 2 of 3 · Trip length', 'Step 3 of 3 · Review'];
        let step = 0;
        let complete = false;

        function chosenDestination() {
            return destinations.find(place => place.id === planner.elements.destination.value);
        }
        function addText(container, tag, text) {
            const element = document.createElement(tag);
            element.textContent = text; // User input is never interpreted as HTML.
            container.append(element);
        }
        function setError(fields, message = '') {
            document.getElementById(fields[0].getAttribute('aria-describedby')).textContent = message;
            for (const field of fields) {
                if (message) field.setAttribute('aria-invalid', 'true');
                else field.removeAttribute('aria-invalid');
            }
        }
        function clearErrors() {
            fieldGroups.flat().forEach(fields => setError(fields));
        }
        function validationIssues(current) {
            const issues = [];
            if (current === 0 && !chosenDestination()) {
                issues.push({ message: 'Choose a destination to start your route.', fields: fieldGroups[0][0] });
            }
            if (current === 1) {
                const name = planner.elements.traveler.value.trim();
                if (!name || name.length > 60) {
                    issues.push({ message: 'Enter your first name using 1 to 60 characters.', fields: fieldGroups[1][0] });
                }
                if (!['1', '2', '3'].includes(planner.elements.days.value)) {
                    issues.push({ message: 'Choose a stay of 1, 2 or 3 days.', fields: fieldGroups[1][1] });
                }
            }
            return issues;
        }
        function showErrors(issues) {
            clearErrors();
            issues.forEach(({ fields, message }) => setError(fields, message));
            issues[0].fields[0].focus();
        }
        function focusStep() {
            const current = steps[step];
            const target = current.querySelector('input:checked') || current.querySelector('input, select') || current.querySelector('legend');
            target.focus();
        }
        function showStep(current) {
            steps.forEach((element, index) => {
                element.hidden = index !== current;
                element.disabled = index !== current;
            });
            result.hidden = true;
            next.hidden = false;
            back.hidden = current === 0;
            clearErrors();
            planner.querySelector('[data-step-label]').textContent = labels[current];
            planner.querySelector('[data-step-progress]').style.width = `${((current + 1) / steps.length) * 100}%`;
            next.textContent = current === 2 ? 'Build my route' : 'Continue';
            if (current === 2) {
                const review = planner.querySelector('[data-trip-review]');
                review.replaceChildren();
                addText(review, 'p', 'Destination: ' + chosenDestination().name);
                addText(review, 'p', 'Traveller: ' + planner.elements.traveler.value.trim());
                const days = Number(planner.elements.days.value);
                addText(review, 'p', `Duration: ${days} ${days === 1 ? 'day' : 'days'}`);
            }
            animate(steps[current]);
        }
        // A higher-order function receives the display callback. Inputs stay in the DOM.
        function changeStep(direction, onStepChanged) {
            const issues = direction > 0 ? validationIssues(step) : [];
            if (issues.length) {
                showErrors(issues);
                return;
            }
            step = Math.max(0, Math.min(2, step + direction));
            onStepChanged(step);
            focusStep();
        }
        function buildRoute() {
            // Recheck every required value before producing the final result.
            for (let index = 0; index < 2; index += 1) {
                const issues = validationIssues(index);
                if (issues.length) {
                    step = index;
                    showStep(step);
                    showErrors(issues);
                    return;
                }
            }
            const place = chosenDestination();
            const days = Number(planner.elements.days.value);
            planner.querySelector('[data-trip-greeting]').textContent = `${planner.elements.traveler.value.trim()}, your route for ${place.name}`;
            planner.querySelector('[data-trip-description]').textContent = place.description;
            const stops = planner.querySelector('[data-trip-stops]');
            stops.replaceChildren();
            // Explicit loop demonstrates array iteration while generating actual DOM nodes.
            const route = place.getRoute(days);
            for (let index = 0; index < route.length; index += 1) addText(stops, 'li', `Day ${index + 1}: ${route[index]}`);
            planner.querySelector('[data-trip-guide]').setAttribute('href', place.id + '.html');
            steps.forEach(element => {
                element.hidden = true;
                element.disabled = true;
            });
            result.hidden = false;
            complete = true;
            next.hidden = true;
            back.hidden = true;
            clearErrors();
            planner.querySelector('[data-step-label]').textContent = 'Your route is ready';
            animate(result);
            result.focus();
            playChime();
        }
        back.addEventListener('click', () => changeStep(-1, showStep));
        planner.querySelector('[data-planner-reset]').addEventListener('click', () => {
            planner.reset();
            step = 0;
            complete = false;
            planner.querySelector('[data-trip-review]').replaceChildren();
            planner.querySelector('[data-trip-greeting]').textContent = '';
            planner.querySelector('[data-trip-description]').textContent = '';
            planner.querySelector('[data-trip-stops]').replaceChildren();
            planner.querySelector('[data-trip-guide]').setAttribute('href', 'aktau.html');
            showStep(step);
            focusStep();
        });
        planner.addEventListener('submit', event => {
            event.preventDefault();
            if (complete) return;
            if (step === 2) buildRoute(); else changeStep(1, showStep);
        });
        planner.addEventListener('input', event => {
            const fields = fieldGroups.flat().find(group => group.includes(event.target));
            if (fields) setError(fields);
        });
        showStep(step);
    }
})();
